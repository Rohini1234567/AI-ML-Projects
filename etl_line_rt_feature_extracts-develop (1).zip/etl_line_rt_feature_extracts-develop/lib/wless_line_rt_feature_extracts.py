import sys
import argparse
import subprocess
from ast import literal_eval
from urllib.parse import urlparse, unquote
from google.cloud import storage, bigquery
from pyspark.sql import SparkSession
from pyspark.sql.functions import struct, collect_list

modelid = "rt_extracts"

class NumberArgumentsError(Exception):
    def __init__(self, message):
        self.message = message


if len(sys.argv) >= 5:
    parser = argparse.ArgumentParser(description="My parser")
    parser.add_argument("--data_project", default='', help="project in bigquery.")
    parser.add_argument("--tmp_bucket", default='', help="bucket.")
    parser.add_argument("--db_output_data", default='',help="output db for sql query.")
    parser.add_argument("--run_date", default='',help="run date.")
    parser.add_argument("--restart_loop_script_path", default='',help="hdfs path for restart_loop.hql script")
    parser.add_argument("--gen_sql_v2_script_path", default='',help="hdfs path for gen_sql_v2.hql script")
    parser.add_argument("--bump_by_1_script_path", default='',help="hdfs path for bump_by_1.hql script")

    print(sys.argv)
    parsed_args = parser.parse_args(sys.argv[1:])
    data_project = parsed_args.data_project
    tmp_bucket = parsed_args.tmp_bucket
    db_output_data = parsed_args.db_output_data
    run_date = parsed_args.run_date
    restart_loop_script_path = parsed_args.restart_loop_script_path
    gen_sql_v2_script_path = parsed_args.gen_sql_v2_script_path
    bump_by_1_script_path = parsed_args.bump_by_1_script_path
else:
    err_msg = ' '.join(['Error:  At least 5 arguments must be passed in:',
                        'db_output_data, run_date, restart_loop_script_path, gen_sql_v2_script_path, bump_by_1_script_path'])
    print(err_msg)
    raise NumberArgumentsError(err_msg)


spark = SparkSession.builder \
            .appName(modelid) \
            .config('viewsEnabled', 'true') \
            .config('materializationProject', data_project) \
            .config('temporaryGcsBucket', tmp_bucket) \
            .getOrCreate()


def parse_url(url):
    result = urlparse(url)
    if result.scheme == 'gs':
        return result.netloc, unquote(result.path.lstrip('/'))
    elif result.scheme == 'https':
        assert result.netloc == 'storage.googleapis.com'
        bucket, rest = result.path.lstrip('/').split('/', 1)
        return bucket, unquote(rest)
    else:
        raise Exception(f'Could not parse {url} as gcs url')

def get_sql_file_contents(url: str) -> str:
    client = storage.Client()
    bucket_name, path = parse_url(url)
    bucket = client.get_bucket(bucket_name)
    blob = bucket.get_blob(path)
    if not blob: return None
    return blob.download_as_text()

def execute_sql_file_contents(contents: str, data_project: str):
    statements = contents.split(";")

    for query in statements:
        if query not in ["", "\n", "\n\n"]:
            print("Query: ", query+";")
            try:
                client = bigquery.Client(project=data_project)
                query_job = client.query(query)
                # return query_job.result()
            except Exception as x:
                print("Unable to process the query\n" + "ERROR : " + str(x))

def load_data(project, sql, spark):
    client = bigquery.Client(project=project)
    query_job = client.query(sql)
    query_job.result()
    df = spark.read.format("bigquery") \
        .option("project", project) \
        .option('dataset', query_job.destination.dataset_id) \
        .load(query_job.destination.table_id)
    return df

def generateSQLQuery(fileSQLContents: str, data_project, spark) -> str:
    df = []
    count = 0
    fileSQLContentsSplit = fileSQLContents.split(";")
    sqlGenerationQueryExecutedOnce = False
    
    for query in fileSQLContentsSplit:
        try:
            if query not in ["", "\n", "\n\n"]:
                query += ";"
                df_ = load_data(data_project, query, spark)
                df.append(df_)
            if len(df) == 1 and sqlGenerationQueryExecutedOnce is False:
                sqlStatementGrouped = df[0].agg(collect_list(struct(["col_order","sql_stmnt"])).alias("tuple_sql_statements"))
                tupleSQLStatements = sqlStatementGrouped.first()["tuple_sql_statements"]
                sortedStatements = sorted(tupleSQLStatements, key=lambda x: x[0])
                finalJoinedSQLQuery = " ".join([x[1] for x in sortedStatements])
                finalJoinedSQLQuery = finalJoinedSQLQuery + ";"
                sqlGenerationQueryExecutedOnce = True
                return finalJoinedSQLQuery
        except Exception as x:
            print("Unable to process the query. ERROR : " + str(x) + "\n")

def replaceGeneratedSQLQuery(query: str, replacementMap: dict) -> str:
    for key in replacementMap.keys():
        query = query.replace(key, replacementMap[key])
    return query

if __name__=='__main__':
    print("Starting main....")
    
    replacementMap = {}
    replacementMap["{data_project}"] = str(data_project)
    replacementMap["{db_output_data}"] = str(db_output_data)
    replacementMap["{run_date}"] = literal_eval(str(run_date))
    print("Replacement Map : ", replacementMap)

    restartLoopQueryFileContents = get_sql_file_contents(str(restart_loop_script_path))
    print("restart_loop query file contents : " + restartLoopQueryFileContents)
    replacedRestartLoopQuery = replaceGeneratedSQLQuery(restartLoopQueryFileContents, replacementMap)
    print("restart_loop query replaced : " + replacedRestartLoopQuery)
    _ = execute_sql_file_contents(replacedRestartLoopQuery, data_project)

    for i in range(7):
        generateSQLQueryFileContents = get_sql_file_contents(str(gen_sql_v2_script_path))
        print("gen_sql_v2 query file contents : " + generateSQLQueryFileContents)
        replacedGenSQLQuery = replaceGeneratedSQLQuery(generateSQLQueryFileContents, replacementMap)
        print("gen_sql_v2 query replaced : " + replacedGenSQLQuery)
        generatedSQLQuery = generateSQLQuery(replacedGenSQLQuery, data_project, spark)
        print("generated query after execution : " + generatedSQLQuery)
        replacedSQLQuery = replaceGeneratedSQLQuery(generatedSQLQuery, replacementMap)
        print("generated query replaced : " + replacedSQLQuery)
        _ = execute_sql_file_contents(replacedSQLQuery, data_project)
    
        bumpByOneQueryFileContents = get_sql_file_contents(str(bump_by_1_script_path))
        print("bump_by_1 query file contents : " + bumpByOneQueryFileContents)
        replacedBumpByOneQuery = replaceGeneratedSQLQuery(bumpByOneQueryFileContents, replacementMap)
        print("bump_by_1 query replaced contents : " + replacedBumpByOneQuery)
        _ = execute_sql_file_contents(replacedBumpByOneQuery, data_project)
