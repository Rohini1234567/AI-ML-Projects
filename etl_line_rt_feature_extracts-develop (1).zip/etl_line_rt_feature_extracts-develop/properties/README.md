# PROPERTIES dir files


### UPDATE - This file should contain your oozie job properties. Update your level and model id in file name.

#### The example properties file can be copied and then you can make edits where needed.  The required updates in the file are to the following properties:
    * appName=[model id] (all caps)
    * appFileName=[mode id] (all lower case)
    * level=[level]

`it_ds_wless_[level]_[model_id].properties`
