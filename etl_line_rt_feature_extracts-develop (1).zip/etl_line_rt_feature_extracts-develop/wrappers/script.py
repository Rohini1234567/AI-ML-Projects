#! /opt/conda/miniconda3/bin/python

import os, sys
import json
import argparse
from google.cloud import bigquery, storage

parser = argparse.ArgumentParser()
parser.add_argument('--sql_script', type=str, required=True)
parser.add_argument('--score_project', type=str, required=False)
parser.add_argument('--data_project', type=str, required=False)
parser.add_argument('--current_project', type=str, required=False)
parser.add_argument('--data_project_cwlspr', type=str, required=False)
parser.add_argument('--external_project', type=str, required=False)
parser.add_argument('--db_models_meta', type=str, required=False)
parser.add_argument('--db_models_metrics', type=str, required=False)
parser.add_argument('--db_ds_prdusr_data', type=str, required=False)

parser.add_argument('--db_dma_data', type=str, required=False)
parser.add_argument('--db_uda_data', type=str, required=False)
parser.add_argument('--tbl_dma_data', type=str, required=False)


parser.add_argument('--db_score_data_acct', type=str, required=False)
parser.add_argument('--tbl_score_data_acct', type=str, required=False)
parser.add_argument('--db_final_score_acct', type=str, required=False)
parser.add_argument('--tbl_final_score_acct', type=str, required=False)


parser.add_argument('--db_inp_data', type=str, required=False)
parser.add_argument('--tbl_inp_data', type=str, required=False)
parser.add_argument('--db_score_data', type=str, required=False)
parser.add_argument('--tbl_score_data', type=str, required=False)
parser.add_argument('--db_final_score', type=str, required=False)
parser.add_argument('--tbl_final_score', type=str, required=False)

parser.add_argument('--wf_id', type=str, required=False)
parser.add_argument('--wf_name', type=str, required=False)
parser.add_argument('--wf_user', type=str, required=False)
parser.add_argument('--wf_group', type=str, required=False)
parser.add_argument('--model_name', type=str, required=False)
parser.add_argument('--env', type=str, required=False)
parser.add_argument('--date', type=str, required=False)
parser.add_argument('--start_time', type=str, required=False)
parser.add_argument('--last_err_node', type=str, required=False)
parser.add_argument('--err_code', type=str, required=False)
parser.add_argument('--err_msg', type=str, required=False)
parser.add_argument('--input_record_cnt', type=str, required=False)
parser.add_argument('--comments', type=str, required=False)
parser.add_argument('--run_date', type=str, required=False)
parser.add_argument('--score_model_id', type=str, required=False)
parser.add_argument('--db_soi_data', type=str, required=False)

args = parser.parse_args()
sql_name = os.path.basename(args.sql_script)
bq_client = bigquery.Client()
storage_client = storage.Client()

def extract_inputs(path_to_sql=str):
    list_of_elements = path_to_sql.split('/')
    bucket_name = list_of_elements[2]
    folder_structure = '/'.join(map(str,list_of_elements[3:-1]))
    sql_file_name = list_of_elements[-1]
    return bucket_name, folder_structure, sql_file_name

bucket_name, folder_structure, sql_file_name = extract_inputs(path_to_sql=args.sql_script)
print(f"Accessing bucket : {bucket_name}")
print(f"Accessing script : {folder_structure}/{sql_file_name}")
print(f"Executing with args : {args}")


bucket = storage_client.bucket(bucket_name)
blob_in = bucket.blob('{}/{}'.format(folder_structure, sql_file_name))

query = blob_in.download_as_string().decode("utf-8")
query = query.format(**vars(args))
print("query: "+query)
query_job = bq_client.query(query)
results = query_job.result()


for row in results:
    print(row.data)


#for row in results:
 # if "select_model_params" in args.sql_script:
  #  print(row.data)
  #else:
   # print('recordsCount=',row.recordsCount)

