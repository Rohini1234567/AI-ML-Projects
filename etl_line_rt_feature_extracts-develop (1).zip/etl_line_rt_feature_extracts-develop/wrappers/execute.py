import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--env', type=str, required=True)
parser.add_argument('--gcs_code_folder', type=str, required=True)
parser.add_argument('--user_name', type=str, required=True)
parser.add_argument('--mode', type=str, required=True)
parser.add_argument('--user', type=str, required=True)
parser.add_argument('--level', type=str, required=True)
parser.add_argument('--scoremodelid', type=str, required=True)
parser.add_argument('--hdfs_dir', type=str, required=True)
parser.add_argument('--data_project', type=str, required=True)
parser.add_argument('--current_project', type=str, required=True)
parser.add_argument('--data_project_cwlspr', type=str, required=True)
parser.add_argument('--external_project', type=str, required=False)
parser.add_argument('--cluster', type=str, required=True)
parser.add_argument('--model', type=str, required=True)
parser.add_argument('--run_date', type=str, required=True)
parser.add_argument('--tmp_bucket', type=str, required=True)
parser.add_argument('--bundle_location',type=str,required=True)
parser.add_argument('--predeploy', type=str, required=True)


args = parser.parse_args()

print("Arguments passed", args)

#first - push code from github to gcs  download to local - done in python file
"""for now github is a gcs location. (this can be taken care of in CICD pipeline.
Once a github repo is updated, the relevant bucket
should also be updated
"""

os.system(f"gsutil -m cp -r {args.gcs_code_folder}/bin/deploy*.sh .")
os.system(f"gsutil -m cp -r {args.gcs_code_folder}/bin/predeploy.sh .")

os.system(f"gsutil -m cp -r {args.gcs_code_folder}/bin/captureRecordsCount.sh .")
os.system(f"gsutil -m cp -r {args.gcs_code_folder}/properties/it_ds_{args.model}.properties .")

os.system(f"gsutil -m cp -r {args.gcs_code_folder}/workflows/*xml .")
os.system(f"gsutil -m cp -r {args.gcs_code_folder}/coordinators/*xml .")

# os.system(f"gsutil -m cp -r {args.gcs_code_folder}/bigquery/*target_data.sql {args.bundle_location}/")

print("List of files present: ", os.listdir())

print("*"*50)
print("Value of run date", args.run_date)
os.system(f"su -c 'sh predeploy.sh {args.env} {args.cluster} {args.user} {args.model}'")

if {args.predeploy} == {'deploy'}:
    os.system(f"su -c 'sh deploy.sh {args.env} {args.model} {args.gcs_code_folder} {args.mode} {args.user} {args.level} {args.scoremodelid} {args.hdfs_dir} {args.data_project} {args.current_project} {args.cluster} {args.tmp_bucket} {args.external_project} {args.data_project_cwlspr} {args.run_date}' {args.user_name}")
# os.system(f"su -c 'sh deploy.sh {args.env} {args.model} {args.gcs_code_folder} {args.mode} {args.user} {args.level} {args.scoremodelid} {args.hdfs_dir} {args.data_project} {args.current_project} {args.score_project} {args.cluster} {args.tmp_bucket} {args.run_date}' {args.user_name}")
