# COORDINATORS dir files


### DON'T CHANGE - Defines oozie coordinator.
`it_ds_gen_model_coordinator.xml`
