-- drop table if exists {data_project}.{db_output_data}.rt_extract_cntrl_tbl;
merge into {data_project}.{db_output_data}.rt_extract_cntrl_tbl a 
using
-- partition (status, rt_feed_name)
(select order_no, 
       filter_sql, 
       insert_ts, 
       CURRENT_TIMESTAMP() as process_ts, 
       'PROCESSED' as status, 
       rt_feed_name  
from {data_project}.{db_output_data}.rt_extract_cntrl_tbl
where status = 'ACTIVE') b
ON FALSE
WHEN NOT MATCHED THEN
 INSERT ROW
WHEN NOT MATCHED BY SOURCE THEN
 DELETE;

-- alter table {data_project}.{db_output_data}.rt_extract_cntrl_tbl
-- drop if exists partition (status = 'ACTIVE');

-- drop table if exists {data_project}.{db_output_data}.rt_extract_cntrl_tbl;
merge into {data_project}.{db_output_data}.rt_extract_cntrl_tbl a
using
--partition (status, rt_feed_name)
(select order_no, 
       filter_sql, 
       CURRENT_TIMESTAMP() as insert_ts, 
       cast (null as timestamp) as process_ts, 
       'ACTIVE' as status, 
       rt_feed_name        
from (select x.order_no, 
             x.rt_feed_name, 
             x.filter_sql,
             ROW_NUMBER() OVER (ORDER BY x.order_no, x.rt_feed_name) AS rank_no
     from {data_project}.{db_output_data}.rt_extract_driver x
     left outer join (select max(order_no) as order_no from {data_project}.{db_output_data}.rt_extract_cntrl_tbl) y
     on 1=1 
     where x.order_no > coalesce (y.order_no,0)
     ) aa
     where rank_no = 1
) b
ON FALSE
WHEN NOT MATCHED THEN
 INSERT ROW
WHEN NOT MATCHED BY SOURCE THEN
 DELETE;
