select * from (
select lpad ('0',5,'0') as col_order,
       concat ('INSERT INTO ', trim(t2.data_project), '.', trim(t2.db_output_data), '.',
       trim(rt_feed_name), ' ', ' SELECT') as sql_stmnt
from {data_project}.{db_output_data}.rt_extract_cntrl_tbl t1
inner join {data_project}.{db_output_data}.rt_extract_constants t2 on 1=1
where status = 'ACTIVE'
  and rt_feed_name <> 'ds_chanorch_postorder_rt'
union all
select lpad ('0',5,'0') as col_order,
       concat ('INSERT INTO ', trim(t2.data_project), '.', trim(t2.db_output_data), '.',
       trim(rt_feed_name), '_b', ' SELECT') as sql_stmnt
from {data_project}.{db_output_data}.rt_extract_cntrl_tbl t1
inner join {data_project}.{db_output_data}.rt_extract_constants t2 on 1=1
where status = 'ACTIVE' 
  and rt_feed_name = 'ds_chanorch_postorder_rt'
union all
select lpad(cast(col_order as STRING), 5, '0'),
       concat (coalesce (ovrrd_sql, cnsldtd_col_name), ' as ', extract_col_name, case when extract_col_name <> 'score_dt' then ',' else ' ' end)  as sql_stmnt
       from {data_project}.{db_output_data}.rt_extract_mapping_tbl t1
       inner join {data_project}.{db_output_data}.rt_extract_cntrl_tbl t2
       on t1.rt_feed_name = t2.rt_feed_name
       where t2.status = 'ACTIVE'
union all
select lpad ("99998",5,'0')  as col_order,
       concat ('from ', trim(t2.data_project), '.', trim(t2.db_output_data), '.ds_feat_dly_rt where score_dt = ', trim(t2.run_date)) as sql_stmnt
from  {data_project}.{db_output_data}.rt_extract_cntrl_tbl t1
inner join {data_project}.{db_output_data}.rt_extract_constants t2 on 1=1
where status = 'ACTIVE'
union all
select lpad ("99999",5,'0') as col_order,
       coalesce (filter_sql, ' ') as sql_stmnt
from  {data_project}.{db_output_data}.rt_extract_cntrl_tbl
where status = 'ACTIVE'
) x order by col_order;
