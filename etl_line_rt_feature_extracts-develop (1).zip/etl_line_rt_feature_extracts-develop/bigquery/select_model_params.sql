select 
concat(
'spark_version=', spark_version, '\n',
'queue_name=', queue_name, '\n',
'queue_name_gpu=', queue_name_gpu, '\n',
'executor_memory=', executor_memory, '\n',
'executor_cores=', executor_cores, '\n',
'driver_memory=', driver_memory, '\n',
'executor_memory_gpu=', executor_memory_gpu, '\n',
'executor_cores_gpu=', executor_cores_gpu, '\n',
'driver_memory_gpu=', driver_memory_gpu, '\n',
'headless_id=', headless_id, '\n',
'spark_dynamic_alloc_enabled=', spark_dynamic_alloc_enabled, '\n',
'spark_dynamic_minExec=', spark_dynamic_minExec, '\n',
'spark_dynamic_maxExec=', spark_dynamic_maxExec, '\n',
'spark_executor_instances=', spark_executor_instances, '\n',
'spark_arrow_enabled=', spark_arrow_enabled, '\n',
'spark_kryoserializer_buffer_max=', spark_kryoserializer_buffer_max, '\n',
'spark_driver_maxResultSize=', spark_driver_maxResultSize, '\n',
'spark_driver_memoryOverhead=', spark_driver_memoryOverhead, '\n',
'spark_executor_memoryOverhead=', spark_executor_memoryOverhead, '\n',
'spark_yarn_maxAppAttempts=', spark_yarn_maxAppAttempts, '\n',
'spark_scheduler_mode=', spark_scheduler_mode, '\n',
'yarn_nodemanager_vmem_check_enabled=', yarn_nodemanager_vmem_check_enabled, '\n',
'docker_image=', docker_image, '\n',
'dr_scoring_code_spark_api=', dr_scoring_code_spark_api, '\n'
) as data
from {external_project}.{db_models_meta}.ds_model_params_meta where score_model_id = '{score_model_id}' and active_flg = 'Y';
