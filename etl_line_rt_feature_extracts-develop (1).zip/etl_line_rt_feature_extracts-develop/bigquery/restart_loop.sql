drop table if exists {data_project}.{db_output_data}.rt_extract_cntrl_tbl;
CREATE TABLE {data_project}.{db_output_data}.rt_extract_cntrl_tbl (
       order_no int,
       filter_sql string, 
       insert_ts timestamp,
       process_ts timestamp,
       status string,
       rt_feed_name string
)
-- PARTITION BY (
-- status, 
-- rt_feed_name
-- );

insert into {data_project}.{db_output_data}.rt_extract_cntrl_tbl
-- partition (status, rt_feed_name)
select order_no, 
       filter_sql, 
       CURRENT_TIMESTAMP() as insert_ts, 
       NULL as process_ts, 
       'ACTIVE' as status, 
       rt_feed_name        
from (select x.order_no, 
             x.rt_feed_name, 
             x.filter_sql,
             ROW_NUMBER() OVER (ORDER BY x.order_no, x.rt_feed_name) AS rank_no
     from {data_project}.{db_output_data}.rt_extract_driver x
     left outer join (select max(order_no) as order_no from {data_project}.{db_output_data}.rt_extract_cntrl_tbl) y
     on 1=1 
     where x.order_no > COALESCE(y.order_no, 0)
     ) a
     where rank_no = 1;