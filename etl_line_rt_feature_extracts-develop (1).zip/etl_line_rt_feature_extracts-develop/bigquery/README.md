# Hive dir files


### UPDATE - This file contains your input sql. Create file with your model id in name.
`create_[model_id]_data.hql`

### UPDATE - Inserts into the global score table for "acct" level models and every other level.  Each level type has it's own insert hql.  Use the one that applies for your model.
`insert_score_wless_[level].hql`

### UPDATE - Inserts into score control table.  There are different versions of this sql based on your type of model.  Make sure you are using the correct one.
`insert_score_cntrl_tbl.hql`

### DON'T CHANGE - Inserts into the error audit table.
`insert_ds_error.hql`

### DON'T CHANGE - Generates count of records in the final output table from input sql.
`countRecords.hql`

### DON'T CHANGE - Inserts total scored records into audit table 
`insert_ds_audit.hql`

