insert into {data_project}.{db_models_meta}.ds_error
(
    wf_id,
    wf_name,
    wf_user,
    wf_group,
    model_name,
    env,
    start_time,
    end_time,
    last_err_node,
    err_code,
    err_msg,
    comments,
    ds
)
select
    '{wf_id}',
    '{wf_name}',
    '{wf_user}',
    '{wf_group}',
    '{model_name}',
    '{env}',
    '{start_time}',
    CAST(CURRENT_TIMESTAMP() AS STRING),
    '{last_err_node}',
    '{err_code}',
    '{err_msg}',
    '{comments}',
    PARSE_DATE('%Y-%m-%d', '{date}')
from {data_project}.{db_models_meta}.ds_dummy;