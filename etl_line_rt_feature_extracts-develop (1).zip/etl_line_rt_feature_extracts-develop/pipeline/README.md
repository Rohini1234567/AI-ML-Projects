# PIPELINE dir files


### CREATE - This file should contain your serialized model. The file can have any name but has to match whatever is used in the pyspark code when loading model.
`[serialized model file name]`
