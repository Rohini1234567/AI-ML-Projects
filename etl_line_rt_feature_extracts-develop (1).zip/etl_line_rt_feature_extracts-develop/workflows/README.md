# WORKFLOW dir files


### DON't CHANGE - This file contains details about the oozie workflow.  There may be updates to this file over time if new global steps are introduced but it's not common.
`it_ds_gen_model_wf.xml`
